import boto3
import re
import os
import datetime

s3 = boto3.client('s3')
sns = boto3.client('sns')

def lambda_handler(event, context):
    logs_bucket = "flogauto-logs"
    reports_bucket = "flogauto-reports"
    sns_topic_arn = "arn:aws:sns:eu-west-1:850017502340:flogauto-alerts"

    # Patrón de ataques básicos
    patterns = {
        "SQL Injection": r"(\b(select|union|insert|drop|delete)\b)",
        "XSS": r"(<script>|%3Cscript)",
        "Brute Force": r"(401 Unauthorized|Invalid password|login failed)"
    }

    for record in event['Records']:
        key = record['s3']['object']['key']
        obj = s3.get_object(Bucket=logs_bucket, Key=key)
        content = obj['Body'].read().decode('utf-8')

        findings = []
        for name, pattern in patterns.items():
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                findings.append(f"{name}: {len(matches)} coincidencias")

        timestamp = datetime.datetime.utcnow().isoformat()
        report_content = f"<h1>Informe de análisis - {timestamp}</h1><ul>"
        for f in findings:
            report_content += f"<li>{f}</li>"
        report_content += "</ul>"

        report_key = f"reports/report-{timestamp}.html"
        s3.put_object(
            Bucket=reports_bucket,
            Key=report_key,
            Body=report_content.encode('utf-8'),
            ContentType='text/html'
        )

        if findings:
            message = f"Ataques detectados en {key}: {', '.join(findings)}"
            sns.publish(TopicArn=sns_topic_arn, Message=message, Subject="⚠️ Alerta de seguridad")

    return {"status": "OK"}
